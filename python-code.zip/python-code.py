import json
import boto3
import datetime
from botocore.exceptions import ClientError
import pandas as pd

def lambda_handler(event, context):
    billing_client = boto3.client('ce')
    today = datetime.date.today()
    first_day_of_month = today.replace(day=1)
    last_day_of_previous_month = first_day_of_month - datetime.timedelta(days=1)
    first_day_of_previous_month = last_day_of_previous_month.replace(day=1)

    str_first_day_of_previous_month = str(first_day_of_previous_month)
    str_last_day_of_previous_month = str(last_day_of_previous_month)

    # Get total cost for the previous month
    response_total = billing_client.get_cost_and_usage(
        TimePeriod={
            'Start': str_first_day_of_previous_month,
            'End': str_last_day_of_previous_month,
        },
        Granularity='MONTHLY',
        Metrics=['UnblendedCost'],
    )

    total_cost = response_total["ResultsByTime"][0]['Total']['UnblendedCost']['Amount']
    total_cost = float(total_cost)
    total_cost = round(total_cost, 3)
    total_cost = '$' + str(total_cost)

    print('Total cost for the previous month: ' + total_cost)

    # Get detailed billing for individual resources
    response_detail = billing_client.get_cost_and_usage(
        TimePeriod={
            'Start': str_first_day_of_previous_month,
            'End': str_last_day_of_previous_month,
        },
        Granularity='MONTHLY',
        Metrics=['UnblendedCost'],
        GroupBy=[
            {
                'Type': 'DIMENSION',
                'Key': 'SERVICE'
            },
            {
                'Type': 'DIMENSION',
                'Key': 'USAGE_TYPE'
            }
        ]
    )

    resources = {'Service': [], 'Usage Type': [], 'Cost': []}

    for result in response_detail['ResultsByTime'][0]['Groups']:
        group_key = result['Keys']
        service = group_key[0]
        usage_type = group_key[1]
        cost = result['Metrics']['UnblendedCost']['Amount']
        cost = float(cost)
        cost = round(cost, 3)

        if cost > 0:
            cost = '$' + str(cost)
            resources['Service'].append(service)
            resources['Usage Type'].append(usage_type)
            resources['Cost'].append(cost)

    df = pd.DataFrame(resources)
    html_table = df.to_html(index=False)

    # Generate HTML Report
    message = 'Cost of AWS training account for the previous month was'

    html = """
            <html>
              <head>
                <style>
                  body {{
                    font-family: Arial, sans-serif;
                    color: white;
                    background-color: black;
                  }}
                  h2 {{
                    color: white;
                    font-size: 25px;
                    text-align: center;
                  }}
                  h1 {{
                    color: #333333;
                    font-size: 40px;
                    text-align: center;
                    background-color: yellow;
                  }}
                  p {{
                    color: white;
                    font-size: 30px;
                    line-height: 1.5;
                    margin-bottom: 20px;
                    text-align: center;
                  }}
                  p1 {{
                     font-size: 10px;
                     text-align: center;
                      margin-left: auto;
                     margin-right: auto;
                  }}
                </style>
              </head>
              <body>
                <p> Training Account Report for the Month: {} - {} </p>
                <h2> {} </h2>
                <h1> <strong> <em> {} </em></strong> </h1>
                <p1>{}</p1>
              </body>
            </html>
            """.format(str_first_day_of_previous_month, str_last_day_of_previous_month, message, total_cost, html_table)

    # Send Email
    ses_client = boto3.client('ses', region_name='us-east-1')

    message = {
        'Subject': {'Data': 'AWS Monthly Cost Report'},
        'Body': {'Html': {'Data': html}}
    }

    response = ses_client.send_email(
        Source='koushiksmenon5@gmail.com',
        Destination={'ToAddresses': ['kousheksmenon8@gmail.com']},
        Message=message
    )

    print(response)
